<?php 
$nama1 = "Rizki Agung Sentosa";
$nama2 = "Mohammad Ridwan Apriyadi";
$nama3 = "Muhammad Rizky Thio";
$nama4 = "Marsellino Raja Putra Tambunan";
$nama5 = "Muhammad Aldi";
$kelas = "15.5A.01";
$kampus = "Universitas Bina Sarana Informatika";
$kelompok = "Kelompok 8 Vigenesia";
$subkelompok = "Project Pengembangan Vigenesia untuk Tugas Mata kuliah Teknologi Web Service di Semester 5";
$artikel1 = "Artikel 1";
$artikel2 = "Artikel 2";
$artikel3 = "Artikel 3";
?>