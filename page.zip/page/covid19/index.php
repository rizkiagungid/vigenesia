<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Covid 19 Informasi</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <iframe src="https://ourworldindata.org/grapher/total-cases-covid-19?tab=map" width="100%" height="600px"></iframe>
        <br>
        <a name="" id="" class="btn btn-primary" href="../home.php" role="button">Kembali</a>
    </body>
</html>